<?php
header ("Location: http://cache.googlevideo.com/get_video?video_id=".$_GET['v']);
exit();
?>